package com.springc.springgroupc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringgroupcApplicationTests {

	@Test
	void contextLoads() {
	}

}
